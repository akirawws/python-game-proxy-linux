from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query

from app.dependencies import config_db, metrics_db, require_admin
from app.storage.factory import metrics_backend_name
from app.storage.repository import Repository, utcnow

router = APIRouter()

RangeKey = Literal["5m", "1h", "24h", "7d"]

RANGES: dict[str, tuple[timedelta, int]] = {
    "5m": (timedelta(minutes=5), 5),
    "1h": (timedelta(hours=1), 30),
    "24h": (timedelta(hours=24), 300),
    "7d": (timedelta(days=7), 1800),
}


def _iso(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return value.isoformat()


def _round(value) -> float:
    return round(float(value or 0.0), 2)


def _bucket_ts(value) -> Optional[str]:
    if value is None:
        return None
    return datetime.fromtimestamp(int(value), tz=timezone.utc).isoformat()


def _grouped(metrics, server_id, date_from, date_to, group_by: str) -> list[dict]:
    rows = metrics.event_stats(
        server_id=server_id,
        date_from=date_from,
        date_to=date_to,
        group_by=group_by,
    )
    prepared: list[dict] = []
    for row in rows:
        item = dict(row)
        item["count"] = int(item.get("count") or 0)
        item["avg_score"] = (
            round(float(item["avg_score"]), 3)
            if item.get("avg_score") is not None
            else None
        )
        item["last_event"] = _iso(item.get("last_event"))
        prepared.append(item)
    prepared.sort(key=lambda item: item["count"], reverse=True)
    return prepared


@router.get("")
def statistics(
    range_key: RangeKey = Query("24h", alias="range"),
    server_id: Optional[int] = Query(default=None, gt=0),
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    window, bucket_seconds = RANGES.get(range_key, RANGES["24h"])
    date_to = utcnow()
    date_from = date_to - window

    points = metrics.query_traffic_series(
        server_id, date_from, date_to, bucket_seconds
    )
    series: list[dict] = []
    for point in points:
        series.append(
            {
                "ts": _bucket_ts(point.get("bucket")),
                "in_pps": _round(point.get("in_pps")),
                "out_pps": _round(point.get("out_pps")),
                "in_bps": _round(point.get("in_bps")),
                "out_bps": _round(point.get("out_bps")),
            }
        )

    in_pps = [item["in_pps"] for item in series]
    out_pps = [item["out_pps"] for item in series]
    traffic = {
        "has_data": bool(series),
        "points": len(series),
        "bucket_seconds": bucket_seconds,
        "peak_in_pps": max(in_pps, default=0.0),
        "peak_out_pps": max(out_pps, default=0.0),
        "avg_in_pps": _round(sum(in_pps) / len(in_pps)) if in_pps else 0.0,
        "avg_out_pps": _round(sum(out_pps) / len(out_pps)) if out_pps else 0.0,
        "total_in_bytes": int(
            sum(float(point.get("in_bytes") or 0) for point in points)
        ),
        "total_out_bytes": int(
            sum(float(point.get("out_bytes") or 0) for point in points)
        ),
        "samples": int(sum(int(point.get("samples") or 0) for point in points)),
        "series": series,
    }

    by_severity = _grouped(metrics, server_id, date_from, date_to, "severity")
    by_type = _grouped(metrics, server_id, date_from, date_to, "event_type")
    by_protocol = _grouped(metrics, server_id, date_from, date_to, "protocol")
    by_status = _grouped(metrics, server_id, date_from, date_to, "action_status")
    events_total = sum(row["count"] for row in by_severity)

    active_rules = repository.list_rules(server_id=server_id, status="all")
    temporary_rules = repository.list_rules(server_id=server_id, status="temporary")
    permanent_rules = repository.list_rules(server_id=server_id, status="permanent")
    expired_rules = repository.list_rules(server_id=server_id, status="expired")
    by_action: dict[str, int] = {}
    for rule in active_rules:
        action = str(rule.get("action") or "unknown")
        by_action[action] = by_action.get(action, 0) + 1

    where = "created_at >= ?"
    params: list = [_iso(date_from)]
    if server_id is not None:
        where += " AND server_id = ?"
        params.append(server_id)
    created_rules = repository.fetch_all("firewall_rules", where, tuple(params))
    _, rule_actions = repository.list_audit(
        action="rule.apply",
        date_from=date_from,
        date_to=date_to,
        page=1,
        page_size=1,
    )

    rules = {
        "active": len(active_rules),
        "temporary": len(temporary_rules),
        "permanent": len(permanent_rules),
        "expired": len(expired_rules),
        "created_in_period": len(created_rules),
        "actions_in_period": int(rule_actions),
        "by_action": [
            {"action": action, "count": count}
            for action, count in sorted(
                by_action.items(), key=lambda item: item[1], reverse=True
            )
        ],
    }

    has_data = traffic["has_data"] or events_total > 0 or rules["active"] > 0
    return {
        "range": range_key,
        "server_id": server_id,
        "window_seconds": int(window.total_seconds()),
        "source": metrics_backend_name(),
        "has_data": has_data,
        "message": None if has_data else "За выбранный период данных нет",
        "traffic": traffic,
        "events": {
            "total": events_total,
            "by_severity": by_severity,
            "by_type": by_type,
            "by_protocol": by_protocol,
            "by_status": by_status,
        },
        "rules": rules,
    }
