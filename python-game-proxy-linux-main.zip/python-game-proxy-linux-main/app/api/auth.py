from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status

from app.api.schemas import LoginRequest
from app.dependencies import (
    audit_service,
    client_ip,
    config_db,
    current_user,
    login_limiter,
)
from app.security.audit import AuditService
from app.security.passwords import hash_password, verify_password
from app.security.rate_limit import LoginRateLimiter
from app.security.sessions import get_or_create_csrf_token, rotate_csrf_token
from app.storage.repository import Repository

router = APIRouter()

                                                                             
_DUMMY_HASH = hash_password("dummy-password-for-timing-only")
GENERIC_ERROR = "Неверный логин или пароль"


@router.get("/csrf")
def csrf_token(request: Request) -> dict:
    return {"csrf_token": get_or_create_csrf_token(request)}


@router.post("/login")
def login(
    payload: LoginRequest,
    request: Request,
    repository: Repository = Depends(config_db),
    limiter: LoginRateLimiter = Depends(login_limiter),
    audit: AuditService = Depends(audit_service),
) -> dict:
    ip = client_ip(request)
    login_value = payload.login.strip()
    limiter_key = f"{ip}|{login_value.lower()}"
    ip_key = f"{ip}|*"

    for key in (limiter_key, ip_key):
        allowed, retry_after = limiter.check(key)
        if not allowed:
            audit.login_failed(login_value, ip, "rate_limited")
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Слишком много попыток входа. Повторите позже",
                headers={"Retry-After": str(retry_after)},
            )

    row = repository.fetch_one("users", "login=?", (login_value,))
    password_hash = row["password_hash"] if row else _DUMMY_HASH
    password_ok = verify_password(payload.password, password_hash)

    if row is None or not password_ok:
        limiter.register_failure(limiter_key)
        limiter.register_failure(ip_key)
        audit.login_failed(login_value, ip, "invalid_credentials")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail=GENERIC_ERROR
        )

    limiter.reset(limiter_key)
    limiter.reset(ip_key)

    request.session.clear()
    request.session["user"] = {
        "id": row["id"],
        "login": row["login"],
        "is_admin": bool(row["is_admin"]),
    }
    token = rotate_csrf_token(request)
    audit.login_success(row["id"], row["login"], ip)

    return {
        "user": {
            "id": row["id"],
            "login": row["login"],
            "is_admin": bool(row["is_admin"]),
        },
        "csrf_token": token,
    }


@router.post("/logout")
def logout(
    request: Request,
    user: dict = Depends(current_user),
    audit: AuditService = Depends(audit_service),
) -> Response:
    audit.logout(user["id"], user["login"], client_ip(request))
    request.session.clear()
    response = Response(status_code=status.HTTP_204_NO_CONTENT)
    response.delete_cookie("netshield_session")
    return response


@router.get("/me")
def me(request: Request, user: dict = Depends(current_user)) -> dict:
    return {
        "user": user,
        "csrf_token": get_or_create_csrf_token(request),
    }
