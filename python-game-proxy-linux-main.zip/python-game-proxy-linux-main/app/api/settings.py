from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from app.api.schemas import SettingsIn
from app.dependencies import audit_service, client_ip, config_db, require_admin
from app.security.audit import AuditService
from app.storage.repository import Repository

router = APIRouter()


def _typed(raw: dict[str, str]) -> dict:
    def as_int(key: str, default: int) -> int:
        try:
            return int(raw.get(key, default))
        except (TypeError, ValueError):
            return default

    return {
        "detection_mode": raw.get("detection_mode", "observation"),
        "auto_actions_enabled": raw.get("auto_actions_enabled", "false") == "true",
        "collection_interval_sec": as_int("collection_interval_sec", 1),
        "confirmation_intervals": as_int("confirmation_intervals", 3),
        "cooldown_seconds": as_int("cooldown_seconds", 60),
        "max_concurrent_blocks": as_int("max_concurrent_blocks", 20),
        "metrics_retention_days": as_int("metrics_retention_days", 7),
        "event_retention_days": as_int("event_retention_days", 90),
    }


@router.get("")
def get_settings(
    repository: Repository = Depends(config_db),
    _: dict = Depends(require_admin),
) -> dict:
    return _typed(repository.get_settings())


@router.put("")
def update_settings(
    payload: SettingsIn,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    if payload.detection_mode == "auto" and not payload.auto_actions_enabled:
        payload = payload.model_copy(update={"auto_actions_enabled": True})

    values = {
        "detection_mode": payload.detection_mode,
        "auto_actions_enabled": "true" if payload.auto_actions_enabled else "false",
        "collection_interval_sec": str(payload.collection_interval_sec),
        "confirmation_intervals": str(payload.confirmation_intervals),
        "cooldown_seconds": str(payload.cooldown_seconds),
        "max_concurrent_blocks": str(payload.max_concurrent_blocks),
        "metrics_retention_days": str(payload.metrics_retention_days),
        "event_retention_days": str(payload.event_retention_days),
    }
    saved = repository.update_settings(values)

    audit.record(
        "settings.update",
        user_id=user["id"],
        ip=client_ip(request),
        details={"detection_mode": payload.detection_mode, "fields": sorted(values)},
    )
    return _typed(saved)
