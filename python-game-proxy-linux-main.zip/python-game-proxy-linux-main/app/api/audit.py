from __future__ import annotations

from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query

from app.dependencies import audit_service, require_admin
from app.security.audit import AuditService
from app.storage.repository import utcnow

router = APIRouter()


@router.get("")
def list_audit(
    action: Optional[str] = Query(default=None, max_length=64),
    result: Optional[str] = Query(default=None, max_length=16),
    hours: int = Query(default=24 * 7, ge=1, le=24 * 90),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    audit: AuditService = Depends(audit_service),
    _: dict = Depends(require_admin),
) -> dict:
    date_to = utcnow()
    date_from = date_to - timedelta(hours=hours)
    items, total = audit.list(
        action=action,
        result=result,
        date_from=date_from,
        date_to=date_to,
        page=page,
        page_size=page_size,
    )
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_data": total > 0,
        "message": None if total > 0 else "Записей аудита нет",
    }
