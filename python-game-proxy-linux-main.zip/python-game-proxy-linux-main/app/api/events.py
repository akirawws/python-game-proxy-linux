from __future__ import annotations

from datetime import timedelta
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query

from app.dependencies import config_db, metrics_db, require_admin
from app.storage.repository import Repository, utcnow

router = APIRouter()


@router.get("")
def list_events(
    server_id: Optional[int] = Query(default=None, gt=0),
    severity: Optional[
        Literal["info", "low", "medium", "high", "critical"]
    ] = Query(default=None),
    event_type: Optional[str] = Query(default=None, max_length=64),
    protocol: Optional[Literal["tcp", "udp"]] = Query(default=None),
    action_status: Optional[str] = Query(default=None, max_length=32),
    hours: int = Query(default=24, ge=1, le=24 * 30),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    date_to = utcnow()
    date_from = date_to - timedelta(hours=hours)

    items, total = metrics.list_events(
        server_id=server_id,
        severity=severity,
        event_type=event_type,
        protocol=protocol,
        action_status=action_status,
        date_from=date_from,
        date_to=date_to,
        page=page,
        page_size=page_size,
    )

    names = {
        server["id"]: server["name"] for server in repository.list_servers(False)
    }
    for item in items:
        item.setdefault("server_name", names.get(item.get("server_id"), "—"))
        timestamp = item.get("timestamp")
        if timestamp is not None and not isinstance(timestamp, str):
            item["timestamp"] = timestamp.isoformat()

    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_data": total > 0,
        "message": None if total > 0 else "Событий за выбранный период нет",
        "range_hours": hours,
    }


@router.get("/stats")
def event_stats(
    server_id: Optional[int] = Query(default=None, gt=0),
    hours: int = Query(default=24, ge=1, le=24 * 30),
    group_by: Literal["severity", "event_type", "protocol", "action_status"] = Query(
        default="severity"
    ),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    date_to = utcnow()
    date_from = date_to - timedelta(hours=hours)
    rows = metrics.event_stats(
        server_id=server_id,
        date_from=date_from,
        date_to=date_to,
        group_by=group_by,
    )
    total = sum(int(row.get("count") or 0) for row in rows)
    return {"items": rows, "total": total, "group_by": group_by}
