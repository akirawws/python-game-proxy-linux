from __future__ import annotations

from fastapi import APIRouter, Response, status

from app.storage.factory import get_config_storage, get_metrics_storage, metrics_backend_name

router = APIRouter()


@router.get("", include_in_schema=False)
def health(response: Response) -> dict:
    config_ok = False
    metrics_ok = False
    try:
        config_ok = get_config_storage().health_check()
    except Exception:
        config_ok = False
    try:
        metrics_ok = bool(get_metrics_storage().health_check())
    except Exception:
        metrics_ok = False

    healthy = config_ok and metrics_ok
    if not healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {
        "status": "ok" if healthy else "degraded",
        "config_db": config_ok,
        "metrics_db": metrics_ok,
        "metrics_source": metrics_backend_name() if metrics_ok else None,
    }
