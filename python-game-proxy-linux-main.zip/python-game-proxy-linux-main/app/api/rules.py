from __future__ import annotations

from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status

from app.api.rule_service import RuleService
from app.api.schemas import RuleIn
from app.dependencies import audit_service, client_ip, config_db, require_admin
from app.security.audit import AuditService
from app.storage.repository import Repository

router = APIRouter()


@router.get("")
def list_rules(
    server_id: Optional[int] = None,
    status_filter: Literal[
        "all", "temporary", "permanent", "expired"
    ] = "all",
    repository: Repository = Depends(config_db),
    _: dict = Depends(require_admin),
) -> dict:
    items = repository.list_rules(server_id=server_id, status=status_filter)
    return {
        "items": items,
        "total": len(items),
        "has_data": bool(items),
        "message": None if items else "Активных правил нет",
    }


@router.post("", status_code=status.HTTP_201_CREATED)
def apply_rule(
    payload: RuleIn,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    service = RuleService(repository)
    result = service.request_rule(
        server_id=payload.server_id,
        action=payload.action,
        ip=payload.ip,
        port=payload.port,
        protocol=payload.protocol,
        ttl_seconds=payload.ttl_seconds,
        reason=payload.reason,
    )

    audit.record(
        "rule.apply",
        result=result["status"],
        user_id=user["id"],
        ip=client_ip(request),
        details={
            "server_id": payload.server_id,
            "action": payload.action,
            "ip": payload.ip,
            "port": payload.port,
            "protocol": payload.protocol,
            "ttl_seconds": payload.ttl_seconds,
            "message": result.get("message", ""),
        },
    )

    if result["status"] == "rejected":
        raise HTTPException(status_code=400, detail=result["message"])
    if result["status"] == "error":
        raise HTTPException(status_code=502, detail=result["message"])
    return result


@router.delete("/{rule_id}")
def cancel_rule(
    rule_id: int,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    result = RuleService(repository).cancel_rule(rule_id)
    audit.record(
        "rule.cancel",
        result=result["status"],
        user_id=user["id"],
        ip=client_ip(request),
        details={"rule_id": rule_id, "message": result.get("message", "")},
    )
    if result["status"] == "rejected":
        raise HTTPException(status_code=404, detail=result["message"])
    return result
