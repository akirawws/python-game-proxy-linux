from __future__ import annotations

import os

from fastapi import APIRouter, Depends

from app.config import get_settings
from app.dependencies import config_db, metrics_db, require_admin
from app.storage.repository import Repository

router = APIRouter()


@router.get("/status")
def security_status(
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    settings = get_settings()
    components = repository.list_system_status()
    checks: list[dict] = []

    checks.append(
        {
            "name": "Ключ сессий",
            "status": "ok"
            if (os.getenv("NETSHIELD_SECRET_KEY") or os.getenv("SECRET_KEY"))
            else "warn",
            "message": "задан в окружении"
            if (os.getenv("NETSHIELD_SECRET_KEY") or os.getenv("SECRET_KEY"))
            else "используется временный ключ, задайте NETSHIELD_SECRET_KEY",
        }
    )
    checks.append(
        {
            "name": "Cookie Secure/HttpOnly",
            "status": "ok" if settings.cookie_secure else "warn",
            "message": "Secure включён"
            if settings.cookie_secure
            else "COOKIE_SECURE=false — включите после настройки HTTPS",
        }
    )
    checks.append(
        {
            "name": "CSRF-защита",
            "status": "ok" if settings.csrf_enabled else "warn",
            "message": "включена" if settings.csrf_enabled else "отключена",
        }
    )

    clickhouse_ok = False
    try:
        clickhouse_ok = bool(metrics.health_check())
    except Exception:
        clickhouse_ok = False
    checks.append(
        {
            "name": "Хранилище метрик",
            "status": "ok" if clickhouse_ok else "warn",
            "message": type(metrics).__name__,
        }
    )

    rules = repository.list_rules(status="all")
    checks.append(
        {
            "name": "Активные правила",
            "status": "ok",
            "message": f"{len(rules)} правил(а)",
        }
    )

    settings_row = repository.get_settings()
    checks.append(
        {
            "name": "Режим обнаружения",
            "status": "ok",
            "message": "наблюдение"
            if settings_row.get("detection_mode") != "auto"
            else "автоматический",
        }
    )

    servers = repository.list_servers()
    inactive = [s["name"] for s in servers if not s["is_active"]]
    checks.append(
        {
            "name": "Защищаемые серверы",
            "status": "warn" if inactive else "ok",
            "message": (
                f"без защиты: {', '.join(inactive)}" if inactive else f"{len(servers)} под защитой"
            ),
        }
    )

    return {"checks": checks, "components": components}
