from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query

from app.dependencies import config_db, metrics_db, require_admin
from app.storage.factory import metrics_backend_name
from app.storage.repository import Repository, utcnow

router = APIRouter()

RangeKey = Literal["5m", "1h", "24h", "7d"]

RANGES: dict[str, tuple[timedelta, int]] = {
                                                              
    "5m": (timedelta(minutes=5), 5),
    "1h": (timedelta(hours=1), 30),
    "24h": (timedelta(hours=24), 300),
    "7d": (timedelta(days=7), 1800),
}

STALE_AFTER = {
    "5m": timedelta(seconds=60),
    "1h": timedelta(minutes=10),
    "24h": timedelta(hours=1),
    "7d": timedelta(hours=6),
}


def _range(query_range: str) -> tuple[timedelta, int]:
    return RANGES.get(query_range, RANGES["1h"])


def _iso(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return value.isoformat()


def _staleness(range_key: str, last_sample: Optional[dict]) -> tuple[bool, Optional[str]]:
    if last_sample is None or last_sample.get("timestamp") is None:
        return True, "Сбор недоступен: метрики не поступали"
    raw = last_sample["timestamp"]
    try:
        parsed = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    except (ValueError, TypeError):
        return False, None
    if utcnow() - parsed > STALE_AFTER.get(range_key, STALE_AFTER["1h"]):
        return True, "Сбор недоступен: данные устарели"
    return False, None


def _series_payload(
    range_key: str,
    server_id: Optional[int],
    points: list[dict],
    last_sample: Optional[dict],
) -> dict:
    _, bucket_seconds = _range(range_key)
    stale, message = _staleness(range_key, last_sample)
    has_data = bool(points)
    for point in points:
        bucket = point.get("bucket")
        if bucket is not None:
            point["ts"] = datetime.fromtimestamp(
                int(bucket), tz=timezone.utc
            ).isoformat()
        point.pop("bucket", None)
        for key, value in list(point.items()):
            if isinstance(value, float):
                point[key] = round(value, 3)
    return {
        "range": range_key,
        "server_id": server_id,
        "bucket_seconds": bucket_seconds,
        "has_data": has_data,
        "stale": stale,
        "message": None if has_data and not stale else (message or "Нет данных"),
        "last_sample": _iso(last_sample.get("timestamp")) if last_sample else None,
        "source": metrics_backend_name(),
        "points": points,
    }


@router.get("/traffic")
def traffic(
    range_key: RangeKey = Query("1h", alias="range"),
    server_id: Optional[int] = Query(default=None, gt=0),
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    window, bucket_seconds = _range(range_key)
    date_to = utcnow()
    date_from = date_to - window
    points = metrics.query_traffic_series(server_id, date_from, date_to, bucket_seconds)
    return _series_payload(
        range_key, server_id, points, metrics.latest_metric(server_id)
    )


@router.get("/connections")
def connections(
    range_key: RangeKey = Query("1h", alias="range"),
    server_id: Optional[int] = Query(default=None, gt=0),
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    window, bucket_seconds = _range(range_key)
    date_to = utcnow()
    date_from = date_to - window
    points = metrics.query_connection_series(
        server_id, date_from, date_to, bucket_seconds
    )
    return _series_payload(
        range_key, server_id, points, metrics.latest_metric(server_id)
    )


@router.get("/overview")
def overview(
    repository: Repository = Depends(config_db),
    metrics=Depends(metrics_db),
    _: dict = Depends(require_admin),
) -> dict:
    date_to = utcnow()
    date_from = date_to - timedelta(minutes=5)
    servers = repository.list_servers()

    items: list[dict] = []
    total_pps = 0.0
    total_bps = 0.0
    for server in servers:
        traffic_points = metrics.query_traffic_series(
            server["id"], date_from, date_to, 60
        )
        connection_points = metrics.query_connection_series(
            server["id"], date_from, date_to, 60
        )
        last_traffic = traffic_points[-1] if traffic_points else {}
        last_connection = connection_points[-1] if connection_points else {}

        in_pps = float(last_traffic.get("in_pps") or 0.0)
        out_pps = float(last_traffic.get("out_pps") or 0.0)
        in_bps = float(last_traffic.get("in_bps") or 0.0)
        total_pps += in_pps + out_pps
        total_bps += in_bps

        last_sample = metrics.latest_metric(server["id"])
        stale, message = _staleness("5m", last_sample)
        items.append(
            {
                "server_id": server["id"],
                "name": server["name"],
                "ip": server["ip"],
                "is_active": bool(server["is_active"]),
                "profile": server.get("profile", "custom"),
                "service_type": server.get("service_type", "custom"),
                "ports": server.get("ports", []),
                "in_pps": round(in_pps, 2),
                "out_pps": round(out_pps, 2),
                "in_bps": round(in_bps, 2),
                "tcp_new": round(float(last_connection.get("tcp_new") or 0.0), 2),
                "udp_pps": round(float(last_connection.get("udp_pps") or 0.0), 2),
                "conntrack_count": int(
                    last_connection.get("conntrack_count") or 0
                ),
                "has_data": not stale,
                "message": message,
                "last_sample": _iso(last_sample.get("timestamp"))
                if last_sample
                else None,
            }
        )

    events_last_day = repository.count_events_since(date_to - timedelta(hours=24))
    settings = repository.get_settings()

    return {
        "gateway": {
            "servers_total": len(servers),
            "servers_active": sum(1 for s in servers if s["is_active"]),
            "metrics_source": metrics_backend_name(),
            "detection_mode": settings.get("detection_mode", "observation"),
            "auto_actions_enabled": settings.get("auto_actions_enabled", "false")
            == "true",
        },
        "totals": {
            "in_pps": round(total_pps, 2),
            "in_bps": round(total_bps, 2),
            "events_24h": events_last_day,
        },
        "items": items,
    }
