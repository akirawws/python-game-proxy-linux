from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, status

from app.api.schemas import PortIn, ServerIn, ServerPatch
from app.dependencies import audit_service, client_ip, config_db, require_admin
from app.security.audit import AuditService
from app.storage.repository import Repository

router = APIRouter()


def _get_or_404(repository: Repository, server_id: int) -> dict:
    server = repository.get_server(server_id)
    if server is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Сервер не найден"
        )
    return server


def _ports_payload(ports: list[PortIn], service_type: str) -> list[dict]:
    return [
        {
            "port": item.port,
            "protocol": item.protocol,
            "service_type": (
                item.service_type if item.service_type != "custom" else service_type
            ),
        }
        for item in ports
    ]


@router.get("")
def list_servers(
    repository: Repository = Depends(config_db),
    _: dict = Depends(require_admin),
) -> dict:
    items = repository.list_servers()
    return {"items": items, "total": len(items)}


@router.post("", status_code=status.HTTP_201_CREATED)
def create_server(
    payload: ServerIn,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    data = payload.model_dump(exclude={"ports"})
    try:
        server_id = repository.create_server(data)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    repository.replace_ports(
        server_id, _ports_payload(payload.ports, payload.service_type)
    )
    audit.record(
        "server.create",
        user_id=user["id"],
        ip=client_ip(request),
        details={"server_id": server_id, "name": payload.name, "ip": payload.ip},
    )
    return _get_or_404(repository, server_id)


@router.get("/{server_id}")
def get_server(
    server_id: int,
    repository: Repository = Depends(config_db),
    _: dict = Depends(require_admin),
) -> dict:
    return _get_or_404(repository, server_id)


@router.patch("/{server_id}")
def update_server(
    server_id: int,
    payload: ServerPatch,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    _get_or_404(repository, server_id)
    changes = payload.model_dump(exclude_unset=True, exclude={"ports"})
    if changes:
        repository.update_server(server_id, changes)
    if payload.ports is not None:
        server = _get_or_404(repository, server_id)
        repository.replace_ports(
            server_id, _ports_payload(payload.ports, server["service_type"])
        )
    audit.record(
        "server.update",
        user_id=user["id"],
        ip=client_ip(request),
        details={"server_id": server_id, "fields": sorted(changes.keys())},
    )
    return _get_or_404(repository, server_id)


@router.delete("/{server_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_server(
    server_id: int,
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> None:
    _get_or_404(repository, server_id)
    repository.delete_server(server_id)
    audit.record(
        "server.delete",
        user_id=user["id"],
        ip=client_ip(request),
        details={"server_id": server_id},
    )


@router.put("/{server_id}/ports")
def replace_ports(
    server_id: int,
    ports: list[PortIn],
    request: Request,
    repository: Repository = Depends(config_db),
    audit: AuditService = Depends(audit_service),
    user: dict = Depends(require_admin),
) -> dict:
    server = _get_or_404(repository, server_id)
    repository.replace_ports(
        server_id, _ports_payload(ports, server["service_type"])
    )
    audit.record(
        "server.ports",
        user_id=user["id"],
        ip=client_ip(request),
        details={"server_id": server_id, "ports": len(ports)},
    )
    return _get_or_404(repository, server_id)


@router.get("/{server_id}/ports")
def list_ports(
    server_id: int,
    repository: Repository = Depends(config_db),
    _: dict = Depends(require_admin),
) -> dict:
    _get_or_404(repository, server_id)
    items = repository.list_ports(server_id)
    return {"items": items, "total": len(items)}
