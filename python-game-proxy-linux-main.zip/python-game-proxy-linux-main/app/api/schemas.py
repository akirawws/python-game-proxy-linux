from __future__ import annotations

import ipaddress
import re
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = [
    "LoginRequest",
    "ServerIn",
    "ServerPatch",
    "PortIn",
    "RuleIn",
    "SettingsIn",
    "validate_ip_value",
    "PROTOCOLS",
    "SERVICE_TYPES",
    "PROFILES",
]

PROTOCOLS = ("tcp", "udp", "both")
SERVICE_TYPES = ("web", "game", "custom")
PROFILES = ("web", "game", "custom")
ACTIONS = ("rate_limit", "block_source", "block_port", "drop", "alert")
INTERFACE_RE = re.compile(r"^[A-Za-z0-9_.:@-]{0,32}$")
CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")


def validate_ip_value(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    try:
        ipaddress.ip_address(value)
    except ValueError as exc:
        raise ValueError("Некорректный IP-адрес (IPv4 или IPv6)") from exc
    return value


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class LoginRequest(StrictModel):
    login: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)

    @field_validator("login")
    @classmethod
    def _login_chars(cls, value: str) -> str:
        if CONTROL_CHARS.search(value):
            raise ValueError("Логин содержит недопустимые символы")
        return value


class PortIn(StrictModel):
    port: int = Field(ge=1, le=65535)
    protocol: Literal["tcp", "udp", "both"] = "tcp"
    service_type: Literal["web", "game", "custom"] = "custom"


class ServerIn(StrictModel):
    name: str = Field(min_length=1, max_length=128)
    ip: str
    interface: str = Field(default="", max_length=32)
    service_type: Literal["web", "game", "custom"] = "custom"
    internal_ip: str = ""
    internal_port: int = Field(default=0, ge=0, le=65535)
    profile: Literal["web", "game", "custom"] = "custom"
    description: str = Field(default="", max_length=512)
    is_active: bool = True
    max_pps: int = Field(default=0, ge=0, le=100_000_000)
    max_bps: int = Field(default=0, ge=0, le=10**12)
    max_new_tcp_per_s: int = Field(default=0, ge=0, le=1_000_000)
    max_udp_pps: int = Field(default=0, ge=0, le=10_000_000)
    max_new_sources: int = Field(default=0, ge=0, le=1_000_000)
    max_connections: int = Field(default=0, ge=0, le=10_000_000)
    ports: list[PortIn] = Field(default_factory=list, max_length=64)

    @field_validator("ip")
    @classmethod
    def _ip(cls, value: str) -> str:
        validated = validate_ip_value(value)
        if not validated:
            raise ValueError("IP-адрес обязателен")
        return validated

    @field_validator("internal_ip")
    @classmethod
    def _internal_ip(cls, value: str) -> str:
        return validate_ip_value(value)

    @field_validator("interface")
    @classmethod
    def _interface(cls, value: str) -> str:
        if value and not INTERFACE_RE.match(value):
            raise ValueError("Некорректное имя интерфейса")
        return value

    @field_validator("name", "description")
    @classmethod
    def _no_control_chars(cls, value: str) -> str:
        if CONTROL_CHARS.search(value):
            raise ValueError("Строка содержит недопустимые символы")
        return value

    @field_validator("ports")
    @classmethod
    def _unique_ports(cls, value: list[PortIn]) -> list[PortIn]:
        seen: set[tuple[int, str]] = set()
        for item in value:
            key = (item.port, item.protocol)
            if key in seen:
                raise ValueError(f"Порт {item.port}/{item.protocol} указан дважды")
            seen.add(key)
        return value


class ServerPatch(StrictModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=128)
    ip: Optional[str] = None
    interface: Optional[str] = Field(default=None, max_length=32)
    service_type: Optional[Literal["web", "game", "custom"]] = None
    internal_ip: Optional[str] = None
    internal_port: Optional[int] = Field(default=None, ge=0, le=65535)
    profile: Optional[Literal["web", "game", "custom"]] = None
    description: Optional[str] = Field(default=None, max_length=512)
    is_active: Optional[bool] = None
    max_pps: Optional[int] = Field(default=None, ge=0, le=100_000_000)
    max_bps: Optional[int] = Field(default=None, ge=0, le=10**12)
    max_new_tcp_per_s: Optional[int] = Field(default=None, ge=0, le=1_000_000)
    max_udp_pps: Optional[int] = Field(default=None, ge=0, le=10_000_000)
    max_new_sources: Optional[int] = Field(default=None, ge=0, le=1_000_000)
    max_connections: Optional[int] = Field(default=None, ge=0, le=10_000_000)
    ports: Optional[list[PortIn]] = Field(default=None, max_length=64)

    @field_validator("ip")
    @classmethod
    def _ip(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        validated = validate_ip_value(value)
        if not validated:
            raise ValueError("IP-адрес обязателен")
        return validated

    @field_validator("internal_ip")
    @classmethod
    def _internal_ip(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        return validate_ip_value(value)

    @field_validator("interface")
    @classmethod
    def _interface(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        if value and not INTERFACE_RE.match(value):
            raise ValueError("Некорректное имя интерфейса")
        return value

    @field_validator("name", "description")
    @classmethod
    def _no_control_chars(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        if CONTROL_CHARS.search(value):
            raise ValueError("Строка содержит недопустимые символы")
        return value


class RuleIn(StrictModel):
    server_id: int = Field(gt=0)
    action: Literal["rate_limit", "block_source", "block_port", "drop", "alert"]
    ip: str = ""
    port: int = Field(default=0, ge=0, le=65535)
    protocol: Literal["tcp", "udp", "both"] = "tcp"
    ttl_seconds: int = Field(default=300, ge=0, le=86_400)
    reason: str = Field(default="", max_length=256)

    @field_validator("ip")
    @classmethod
    def _ip(cls, value: str) -> str:
        return validate_ip_value(value)


class SettingsIn(StrictModel):
    detection_mode: Literal["observation", "auto"] = "observation"
    auto_actions_enabled: bool = False
    collection_interval_sec: int = Field(default=1, ge=1, le=60)
    confirmation_intervals: int = Field(default=3, ge=1, le=10)
    cooldown_seconds: int = Field(default=60, ge=0, le=86_400)
    max_concurrent_blocks: int = Field(default=20, ge=0, le=1_000)
    metrics_retention_days: int = Field(default=7, ge=1, le=365)
    event_retention_days: int = Field(default=90, ge=1, le=365)


class EventQuery(StrictModel):
    server_id: Optional[int] = Field(default=None, gt=0)
    severity: Optional[Literal["info", "low", "medium", "high", "critical"]] = None
    event_type: Optional[str] = Field(default=None, max_length=64)
    protocol: Optional[Literal["tcp", "udp"]] = None
    action_status: Optional[str] = Field(default=None, max_length=32)
    hours: int = Field(default=24, ge=1, le=24 * 7)
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=200)
