from __future__ import annotations

import logging
from datetime import timedelta
from typing import Optional

from app.storage.repository import Repository, utcnow

__all__ = ["RuleService", "ALLOWED_ACTIONS", "ACTION_TO_POLICY"]

log = logging.getLogger("netshield.rules")

                                                                             
ALLOWED_ACTIONS = ("rate_limit", "block_source", "block_port", "drop", "alert")

                                                                             
ACTION_TO_POLICY = {
    "rate_limit": "RATE_LIMIT",
    "block_source": "BLOCK_SOURCE",
    "block_port": "PORT_RULE",
    "drop": "DROP",
    "alert": "ALERT",
}


class RuleService:
                                                                            
    def __init__(self, repository: Repository) -> None:
        self.repository = repository

    def request_rule(
        self,
        *,
        server_id: int,
        action: str,
        ip: str = "",
        port: int = 0,
        protocol: str = "tcp",
        ttl_seconds: int = 300,
        reason: str = "",
    ) -> dict:
        if action not in ALLOWED_ACTIONS:
            return {
                "status": "rejected",
                "message": "Недопустимое действие",
                "rule_id": None,
            }

        server = self.repository.get_server(server_id)
        if server is None:
            return {
                "status": "rejected",
                "message": "Сервер не найден",
                "rule_id": None,
            }

        if port and not any(
            item["port"] == port for item in server.get("ports", [])
        ):
            return {
                "status": "rejected",
                "message": "Порт не принадлежит защищаемому серверу",
                "rule_id": None,
            }

        now = utcnow()
        expires_at = (now + timedelta(seconds=ttl_seconds)) if ttl_seconds else None
        rule_id = self.repository.create_rule(
            {
                "server_id": server_id,
                "ip": ip,
                "port": port,
                "protocol": protocol,
                "action": action,
                "expires_at": expires_at,
                "is_active": 1,
                "rule_type": "temporary" if expires_at else "permanent",
                "reason": reason,
                "created_at": now,
            }
        )

        manager = self._manager()
        if manager is None:
            return {
                "status": "pending",
                "message": (
                    "Rule Manager недоступен: правило сохранено в журнале "
                    "и будет применено после интеграции с nftables"
                ),
                "rule_id": rule_id,
            }

        try:
            result = self._apply_with_manager(
                manager, server, action, ip, port, protocol, expires_at, reason
            )
        except Exception as exc:                              
            log.exception("Ошибка применения правила через Rule Manager")
            return {
                "status": "error",
                "message": f"Ошибка применения правила: {type(exc).__name__}",
                "rule_id": rule_id,
            }

        return {
            "status": getattr(result, "status", "applied"),
            "message": getattr(result, "reason", "") or "",
            "rule_id": rule_id,
        }

    def cancel_rule(self, rule_id: int) -> dict:
        rule = self.repository.get_rule(rule_id)
        if rule is None:
            return {"status": "rejected", "message": "Правило не найдено"}
        self.repository.deactivate_rule(rule_id)
        return {"status": "cancelled", "message": "Правило снято"}

    def _manager(self):
                                                                           
        try:
            from app.firewall.integration import create_rule_manager  # type: ignore
        except Exception:
            return None
        try:
            return create_rule_manager(self.repository)
        except Exception:
            log.exception("Не удалось создать Rule Manager")
            return None

    def _apply_with_manager(
        self, manager, server, action, ip, port, protocol, expires_at, reason
    ):
        from app.firewall.policy import ActionType
        from app.firewall.rule_manager import RuleDecision

        member_name = ACTION_TO_POLICY[action]
        action_member = getattr(ActionType, member_name, None)
        if action_member is None:
            raise ValueError(f"Действие {action} не поддерживается Rule Manager")

        decision = RuleDecision(
            action=action_member,
            server_id=server["id"],
            ip=ip or "",
            port=port or 0,
            protocol=protocol,
            expires_at=expires_at,
            reason=reason or "",
        )
        return manager.apply_decision(decision)
