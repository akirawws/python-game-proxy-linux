from __future__ import annotations

import hmac
import secrets

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import JSONResponse

from app.config import get_settings

__all__ = [
    "CSRF_HEADER",
    "CSRF_SESSION_KEY",
    "CSRFMiddleware",
    "get_or_create_csrf_token",
    "rotate_csrf_token",
    "setup_session_middleware",
]

SESSION_COOKIE = "netshield_session"
CSRF_SESSION_KEY = "csrf_token"
CSRF_HEADER = "X-CSRF-Token"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}
CSRF_EXEMPT_PATHS = {"/api/health"}


def get_or_create_csrf_token(request: Request) -> str:
    token = request.session.get(CSRF_SESSION_KEY)
    if not token:
        token = secrets.token_urlsafe(32)
        request.session[CSRF_SESSION_KEY] = token
    return token


def rotate_csrf_token(request: Request) -> str:
    token = secrets.token_urlsafe(32)
    request.session[CSRF_SESSION_KEY] = token
    return token


class CSRFMiddleware(BaseHTTPMiddleware):
                                                                        
    async def dispatch(self, request: Request, call_next):
        settings = get_settings()
        if (
            settings.csrf_enabled
            and request.method.upper() not in SAFE_METHODS
            and request.url.path not in CSRF_EXEMPT_PATHS
        ):
            expected = request.session.get(CSRF_SESSION_KEY)
            provided = request.headers.get(CSRF_HEADER, "")
            if not expected or not provided or not hmac.compare_digest(
                str(expected), str(provided)
            ):
                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": "CSRF-токен отсутствует или недействителен",
                        "code": "csrf_failed",
                    },
                )
        return await call_next(request)


def setup_session_middleware(app) -> None:
    settings = get_settings()
                                                                   
    app.add_middleware(CSRFMiddleware)
    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.secret_key,
        session_cookie=SESSION_COOKIE,
        max_age=settings.session_max_age,
        same_site=settings.cookie_samesite,
        https_only=settings.cookie_secure,
    )
