from __future__ import annotations

from passlib.context import CryptContext

__all__ = ["hash_password", "verify_password", "needs_update"]

_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    if not password or len(password) < 8:
        raise ValueError("Пароль должен содержать не менее 8 символов")
    return _context.hash(password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    if not plain_password or not password_hash:
        return False
    try:
        return _context.verify(plain_password, password_hash)
    except ValueError:
        return False


def needs_update(password_hash: str) -> bool:
    try:
        return _context.needs_update(password_hash)
    except ValueError:
        return False
