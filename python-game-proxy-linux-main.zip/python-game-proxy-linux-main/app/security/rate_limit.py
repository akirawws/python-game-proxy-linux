from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

__all__ = ["LoginRateLimiter", "RateLimitState"]


@dataclass
class RateLimitState:
    failures: list[float] = field(default_factory=list)
    locked_until: float = 0.0


class LoginRateLimiter:
                                                                             
    def __init__(
        self,
        max_attempts: int = 5,
        window_seconds: int = 300,
        lockout_seconds: int = 900,
    ) -> None:
        self.max_attempts = max(1, int(max_attempts))
        self.window_seconds = max(1, int(window_seconds))
        self.lockout_seconds = max(1, int(lockout_seconds))
        self._states: dict[str, RateLimitState] = {}
        self._lock = threading.Lock()

    def _now(self) -> float:
        return time.monotonic()

    def check(self, key: str) -> tuple[bool, int]:
        with self._lock:
            state = self._states.get(key)
            if state is None:
                return True, 0
            now = self._now()
            if state.locked_until > now:
                return False, int(round(state.locked_until - now))
            self._prune(state, now)
            return True, 0

    def register_failure(self, key: str) -> int:
        with self._lock:
            now = self._now()
            state = self._states.setdefault(key, RateLimitState())
            self._prune(state, now)
            state.failures.append(now)
            if len(state.failures) >= self.max_attempts:
                state.locked_until = now + self.lockout_seconds
                state.failures.clear()
                return self.lockout_seconds
            return 0

    def reset(self, key: str) -> None:
        with self._lock:
            self._states.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._states.clear()

    def _prune(self, state: RateLimitState, now: float) -> None:
        if state.failures and now - state.failures[0] > self.window_seconds:
            state.failures = [
                ts for ts in state.failures if now - ts <= self.window_seconds
            ]
