from __future__ import annotations

import json
import logging
from typing import Any, Optional

__all__ = ["AuditService", "scrub_secrets", "SENSITIVE_KEYS"]

log = logging.getLogger("netshield.audit")

SENSITIVE_KEYS = (
    "password",
    "passwd",
    "pwd",
    "token",
    "secret",
    "csrf",
    "authorization",
    "cookie",
    "hash",
    "session",
)
REDACTED = "***"
MAX_DETAILS_LENGTH = 2000


def _is_sensitive(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in SENSITIVE_KEYS)


def scrub_secrets(value: Any) -> Any:
                                                                             
    if isinstance(value, dict):
        return {
            key: (REDACTED if _is_sensitive(str(key)) else scrub_secrets(item))
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [scrub_secrets(item) for item in value]
    return value


class AuditService:
    def __init__(self, repository) -> None:
        self.repository = repository

    def record(
        self,
        action: str,
        *,
        result: str = "ok",
        user_id: Optional[int] = None,
        details: Optional[Any] = None,
        ip: Optional[str] = None,
    ) -> int:
        payload = scrub_secrets(details) if details is not None else {}
        if ip:
            payload = {**payload, "ip": ip} if isinstance(payload, dict) else {"value": payload, "ip": ip}
        text = json.dumps(payload, ensure_ascii=False, default=str)
        if len(text) > MAX_DETAILS_LENGTH:
            text = text[:MAX_DETAILS_LENGTH] + "…"
        log.info("audit action=%s result=%s", action, result)
        return self.repository.append_audit(
            action=action,
            details=text,
            user_id=user_id,
            result=result,
        )

    def login_success(self, user_id: Optional[int], login: str, ip: str) -> int:
        return self.record(
            "auth.login", result="ok", user_id=user_id, details={"login": login}, ip=ip
        )

    def login_failed(self, login: str, ip: str, reason: str) -> int:
        return self.record(
            "auth.login",
            result="fail",
            details={"login": login, "reason": reason},
            ip=ip,
        )

    def logout(self, user_id: Optional[int], login: str, ip: str) -> int:
        return self.record(
            "auth.logout", result="ok", user_id=user_id, details={"login": login}, ip=ip
        )

    def list(
        self,
        action: Optional[str] = None,
        result: Optional[str] = None,
        date_from=None,
        date_to=None,
        page: int = 1,
        page_size: int = 50,
    ):
        return self.repository.list_audit(
            action=action,
            result=result,
            date_from=date_from,
            date_to=date_to,
            page=page,
            page_size=page_size,
        )
