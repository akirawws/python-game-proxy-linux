# NetShield — панель оператора

Веб-панель и REST API системы обнаружения аномального сетевого трафика и защиты
веб-/игровых серверов от DDoS-атак.

Репозиторий разделён между тремя участниками:

| Участник | Зона ответственности |
| --- | --- |
| Кирилл | `scripts/`, `app/firewall/`, `deploy/` — nftables, Rule Manager, развёртывание |
| Денис | `app/collector/`, `app/detector/`, `app/storage/` — сбор метрик, детекторы, ClickHouse |
| **Артур** | `app/api/`, `app/security/`, `web/`, `tests/test_auth.py`, `tests/test_api.py` — FastAPI, React-панель, аутентификация, аудит, проверки безопасности |

## Стек

- **Бэкенд:** FastAPI + Pydantic v2, Uvicorn, SQLite (конфигурация), ClickHouse (метрики)
- **Фронтенд:** React 18 + Vite 6, React Router, Chart.js
- **Аутентификация:** серверные сессии (подписанная cookie), bcrypt, CSRF double-submit
- **Тесты:** pytest + FastAPI TestClient

## Структура

```
app/
  api/            # REST-эндпоинты: auth, servers, metrics, events, rules, stats, settings, audit, security, health
  security/       # пароли, сессии, CSRF, rate limit, аудит
  storage/        # доступ к данным (SQLite + ClickHouse)
  config.py       # конфигурация из окружения/.env
  dependencies.py # FastAPI-зависимости (текущий пользователь, аудит, хранилища)
  main.py         # фабрика приложения, middleware, раздача SPA
  cli.py          # create-admin, set-password, list-users, init-db, serve
web/
  frontend/       # исходники React-приложения (Vite)
  static/dist/    # результат сборки, раздаётся FastAPI
  deploy/         # пример конфигурации nginx (TLS, прокси, rate limit)
tests/
  test_auth.py    # аутентификация, CSRF, rate limit, аудит
  test_api.py     # API, валидация, изоляция серверов, метрики, события, правила
docs/
  api.md          # описание REST API
  integration.md  # контракты для модулей firewall/collector
  admin-guide.md  # установка, эксплуатация, резервное копирование, чек-лист
```

## Быстрый старт

### 1. Бэкенд

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows (PowerShell):
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt

cp .env.example .env          # Windows: copy .env.example .env
# отредактируйте .env: NETSHIELD_SECRET_KEY, NETSHIELD_ADMIN_PASSWORD

python -m app.cli create-admin     # если не задан NETSHIELD_ADMIN_PASSWORD
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Панель: <http://127.0.0.1:8000> · OpenAPI: <http://127.0.0.1:8000/api/docs>

### 2. Фронтенд

```bash
cd web/frontend
npm install
npm run build        # сборка в web/static/dist (её раздаёт FastAPI)
```

Разработка с горячей перезагрузкой (API проксируется на порт 8000):

```bash
cd web/frontend
npm run dev          # http://127.0.0.1:5173
```

Без собранного `web/static/dist` корневой маршрут вернёт 503 с подсказкой —
API при этом полностью работоспособен.

### 3. Тесты

```bash
pip install -r requirements-dev.txt
python -m pytest tests/test_auth.py tests/test_api.py -q
```

`tests/test_firewall.py` относится к части Кирилла и требует реализованных
`app/firewall/*.py`; до их появления запускайте только свои файлы.

## Возможности панели

- **Дашборд** — сводка по серверам, суммарный поток, события за 24 часа, индикатор
  режима «наблюдение / авто», источник метрик (ClickHouse/SQLite), автообновление.
- **Серверы** — CRUD защищаемых серверов, профили (`web`/`game`/`custom`), порты,
  пороговые лимиты, внутренний адрес за прокси.
- **Трафик** — графики in/out pps и бит/с за 5 минут / час / сутки / неделю.
- **Статистика** — сводка за период: пиковая и средняя нагрузка, события по
  важности/типу/протоколу/статусу, активные и созданные правила.
- **Соединения** — новые TCP, UDP pps, conntrack, новые источники.
- **События** — фильтры по серверу, важности, протоколу, статусу действия и периоду,
  статистика по важности, карточка с техническими деталями.
- **Правила** — ручное создание правил (`rate_limit`, `block_source`, `block_port`,
  `drop`, `alert`), TTL, снятие правил, статус применения.
- **Настройки** — режим обнаружения, интервал сбора, подтверждения, cooldown,
  лимит блокировок, сроки хранения.
- **Безопасность** — проверки конфигурации (ключ сессий, Secure-cookie, CSRF,
  хранилище, режим, состояние серверов) и статусы подсистем.
- **Аудит** — журнал входов/выходов, изменений серверов, правил и настроек,
  с маскированием чувствительных полей.

Все состояния «нет данных» отображаются явно: пустой график, отсутствие событий,
устаревшие метрики сопровождаются пояснением.

## Безопасность

- Пароли хранятся только в виде bcrypt-хешей (`passlib`), минимум 8 символов.
- Сессия — подписанная cookie `netshield_session` (`HttpOnly`, `SameSite`, `Secure`
  при `COOKIE_SECURE=true`), секрет — `NETSHIELD_SECRET_KEY`.
- CSRF: double-submit через заголовок `X-CSRF-Token`; токен выдаёт
  `GET /api/auth/csrf` и ротируется при входе. Все изменяющие запросы без токена
  получают `403 csrf_failed`.
- Rate limit входа: `LOGIN_MAX_ATTEMPTS` неудач за `LOGIN_WINDOW_SECONDS` →
  блокировка на `LOGIN_LOCKOUT_SECONDS` (ответ `429` с `Retry-After`).
- Параметр `trust_proxy_headers` учитывает `X-Forwarded-For` только если панель
  действительно стоит за reverse-proxy.
- Аудит пишется в БД; поля с `password`, `token`, `secret`, `csrf`, `cookie`,
  `session`, `hash` заменяются на `***`.
- Все входные данные валидируются строгими Pydantic-моделями (`extra="forbid"`):
  лишние поля, некорректные IP/порты/протоколы и управляющие символы отклоняются
  с `422`.
- Заголовки ответов: `Content-Security-Policy`, `X-Frame-Options: DENY`,
  `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`,
  `Permissions-Policy`; каждый запрос получает `X-Request-ID`.
- Панель **никогда не исполняет shell-команды**: правила передаются менеджеру
  firewall (`app/firewall/integration.py`), при его отсутствии правило сохраняется
  со статусом `pending`.

Для промышленной эксплуатации см. `web/deploy/nginx-netshield.conf` (TLS,
редирект с HTTP, проксирование на 127.0.0.1:8000).

## Хранилище

- Конфигурация (пользователи, серверы, порты, правила, настройки, аудит, статусы)
  всегда хранится в SQLite — файл `SQLITE_DB_PATH`.
- Метрики и события читаются из SQLite либо из ClickHouse в зависимости от
  `STORAGE_BACKEND` (`sqlite` / `clickhouse`).
- Если `STORAGE_BACKEND=clickhouse`, но ClickHouse недоступен, API продолжает
  работать на SQLite, а в статусе подсистем фиксируется ошибка — панель не падает.
- Схема SQLite обновляется автоматически при старте (миграции `ALTER TABLE`).

## Ограничения и интеграция

- Применение правил к nftables выполняет модуль Кирилла. Контракт описан в
  `docs/integration.md`; до его реализации API возвращает `status: "pending"`.
- Метрики поступают от collector Дениса; при отсутствии данных панель показывает
  «нет данных» и предупреждение об устаревании, а не нули.
- `tests/test_firewall.py` требует реализации `app/firewall/policy.py`,
  `app/firewall/rule_manager.py` и `app/firewall/integration.py`.

## Документация

- `docs/api.md` — эндпоинты, коды ответов, примеры запросов.
- `docs/integration.md` — контракты данных и интеграции с firewall/collector.
- `docs/admin-guide.md` — установка, systemd, nginx, права доступа, резервное
  копирование и чек-лист приёмки.
