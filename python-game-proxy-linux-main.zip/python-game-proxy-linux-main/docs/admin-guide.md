# Руководство администратора NetShield

Документ описывает установку, настройку и эксплуатацию панели оператора
(часть Артура: `app/api/`, `app/security/`, `web/`). Установка nftables,
сборщика метрик и детекторов описана в документации соответствующих модулей.

## 1. Состав и требования

| Компонент | Назначение |
| --- | --- |
| FastAPI (`app.main:app`) | REST API, сессии, CSRF, аудит, раздача React-сборки |
| SQLite (`SQLITE_DB_PATH`) | Пользователи, серверы, порты, правила, настройки, аудит |
| ClickHouse (опционально) | Метрики трафика, соединений и события обнаружения |
| React (`web/static/dist`) | Панель оператора (собирается Vite) |
| nginx | TLS-терминация, reverse proxy, ограничение частоты входа |

Требования: Linux, Python 3.11+, Node.js 18+ (только для сборки фронтенда),
исходящий доступ к ClickHouse (если используется). Панель рассчитана на одного
администратора; отдельной роли «наблюдатель» в первой версии нет.

## 2. Установка

```bash
sudo useradd --system --home /opt/netshield --shell /usr/sbin/nologin netshield
sudo mkdir -p /opt/netshield
sudo chown netshield:netshield /opt/netshield

# код проекта уже размещён в /opt/netshield
cd /opt/netshield

python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt

# фронтенд собирается один раз (или при каждом обновлении UI)
cd web/frontend
npm ci
npm run build
cd ../..
```

Сборка попадает в `web/static/dist`. Каталог исключён из git — на сервере его
нужно собрать или скопировать готовым. Пока сборки нет, `/` возвращает `503` с
подсказкой, но API работает.

## 3. Конфигурация

```bash
sudo -u netshield cp .env.example .env
sudo -u netshield chmod 600 .env
sudo -u netshield nano .env
```

Обязательно измените:

- `NETSHIELD_SECRET_KEY` — случайная строка ≥ 32 символов
  (`python3 -c "import secrets; print(secrets.token_urlsafe(48))"`);
- `NETSHIELD_ADMIN_PASSWORD` — сильный пароль первого администратора;
- `SQLITE_DB_PATH` — лучше вне каталога кода, например
  `/var/lib/netshield/netshield.db`;
- `COOKIE_SECURE=true` и `TRUST_PROXY_HEADERS=true` — после настройки HTTPS.

Основные переменные:

| Переменная | По умолчанию | Назначение |
| --- | --- | --- |
| `NETSHIELD_HOST` / `NETSHIELD_PORT` | `127.0.0.1` / `8000` | адрес uvicorn |
| `NETSHIELD_SECRET_KEY` | генерируется | подпись cookie сессии |
| `COOKIE_SECURE` | `false` | cookie только по HTTPS |
| `COOKIE_SAMESITE` | `lax` | `lax` / `strict` / `none` |
| `SESSION_MAX_AGE` | `3600` | время жизни сессии, с |
| `CSRF_ENABLED` | `true` | защита изменяющих запросов |
| `LOGIN_MAX_ATTEMPTS` | `5` | неудачных входов до блокировки |
| `LOGIN_WINDOW_SECONDS` | `300` | окно подсчёта попыток |
| `LOGIN_LOCKOUT_SECONDS` | `900` | длительность блокировки |
| `TRUST_PROXY_HEADERS` | `false` | доверять `X-Forwarded-For` |
| `STORAGE_BACKEND` | `sqlite` | `sqlite` или `clickhouse` |
| `CLICKHOUSE_*` | localhost | подключение к ClickHouse |
| `NETSHIELD_FRONTEND_DIST` | `web/static/dist` | каталог сборки UI |

Не коммитьте `.env` в git и не передавайте его содержимое в тикетах: файл
содержит секрет сессий и пароль администратора.

## 4. Первый запуск и администратор

```bash
cd /opt/netshield
sudo -u netshield SQLITE_DB_PATH=/var/lib/netshield/netshield.db \
  .venv/bin/python -m app.cli init-db

# создать администратора вручную (если NETSHIELD_ADMIN_PASSWORD не задан)
sudo -u netshield SQLITE_DB_PATH=/var/lib/netshield/netshield.db \
  .venv/bin/python -m app.cli create-admin --login admin
```

Проверка:

```bash
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
curl -fsS http://127.0.0.1:8000/api/health
```

Если БД пуста и задан `NETSHIELD_ADMIN_PASSWORD`, администратор создаётся
автоматически при старте. Пароль из `.env` после этого можно удалить, чтобы он
не хранился в открытом виде; смена пароля:

```bash
.venv/bin/python -m app.cli set-password admin
.venv/bin/python -m app.cli list-users
```

## 5. systemd

`/etc/systemd/system/netshield.service`:

```ini
[Unit]
Description=NetShield panel API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=netshield
Group=netshield
WorkingDirectory=/opt/netshield
EnvironmentFile=/opt/netshield/.env
Environment=SQLITE_DB_PATH=/var/lib/netshield/netshield.db
Environment=PYTHONDONTWRITEBYTECODE=1
ExecStart=/opt/netshield/.venv/bin/python -m uvicorn app.main:app \
    --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips=127.0.0.1
Restart=on-failure
RestartSec=3

# Ограничения прав
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/netshield
StateDirectory=netshield

[Install]
WantedBy=multi-user.target
```

```bash
sudo mkdir -p /var/lib/netshield
sudo chown netshield:netshield /var/lib/netshield
sudo chmod 750 /var/lib/netshield
sudo systemctl daemon-reload
sudo systemctl enable --now netshield
sudo systemctl status netshield
```

Обновление кода: остановить сервис, обновить файлы и зависимости
(`pip install -r requirements.txt`, при необходимости `npm ci && npm run build`),
запустить снова. Схема SQLite мигрируется автоматически при старте.

## 6. nginx и HTTPS

Готовый пример: `web/deploy/nginx-netshield.conf`. Порядок:

1. получить сертификат (например, Let's Encrypt `certbot`);
2. заменить `netshield.example.com` и пути к сертификату;
3. создать `/etc/nginx/snippets/netshield-proxy-headers.conf` (блок в конце
   примера);
4. включить сайт, выполнить `sudo nginx -t && sudo systemctl reload nginx`.

В `.env` при этом должны быть `COOKIE_SECURE=true` и
`TRUST_PROXY_HEADERS=true`, иначе cookie не будет отправляться, а в аудите
окажется IP nginx.

## 7. Права доступа и защита секретов

- `.env` — `chmod 600`, владелец `netshield`; каталог `/opt/netshield` — `750`.
- SQLite-файл и каталог `/var/lib/netshield` — `chmod 750` для каталога,
  `chmod 640` для `*.db`; доступ только пользователю сервиса и группе
  администраторов.
- ClickHouse: отдельный пользователь с правами `SELECT`, `CREATE TABLE` и
  `ALTER TABLE` на `netshield.*` (панель при старте создаёт схему и выполняет
  идемпотентную миграцию). Права `INSERT` панели не нужны — метрики пишет
  collector; `DROP` также не требуется. Пароль — только в `.env`,
  `CLICKHOUSE_VERIFY=true` при TLS.
- API не принимает параметры shell-команд; лишние поля и управляющие символы
  отклоняются валидацией (`422`).
- В логи и аудит не попадают пароли, токены, cookie и хэши: значения
  маскируются (`***`). Не включайте `NETSHIELD_DEBUG=true` на рабочем сервере.
- Не открывайте порт 8000 наружу: uvicorn слушает `127.0.0.1`, доступ — только
  через nginx/VPN.

## 8. Резервное копирование

Конфигурация и аудит (SQLite) — обязательная резервная копия. Метрики
ClickHouse можно не сохранять, если допустима потеря истории.

```bash
# корректный снимок SQLite на работающем сервисе
sudo -u netshield sqlite3 /var/lib/netshield/netshield.db \
  ".backup '/var/backups/netshield-$(date +%F).db'"
sudo chmod 600 /var/backups/netshield-*.db

# ClickHouse (пример)
clickhouse-client --query "BACKUP DATABASE netshield TO Disk('backups', 'netshield-$(date +%F).zip')"
```

Проверяйте восстановление на тестовом стенде не реже раза в квартал:
остановить сервис, заменить файл БД, запустить, проверить `/api/health` и вход.
Храните копии вне сервера, шифруйте и ограничивайте доступ.

## 9. Мониторинг и обслуживание

- `GET /api/health` — публичная проверка (`200` — норма, `503` — деградация).
  Используйте её в systemd/внешнем мониторинге.
- Панель → «Безопасность» — проверки ключа сессий, cookie, CSRF, хранилища,
  режима обнаружения и состояния серверов.
- Панель → «Статистика» — нагрузка, события и правила за 5 минут / час / сутки /
  неделю; пустые состояния показывают, что данные не поступают.
- Журнал: `journalctl -u netshield -f`. Каждый запрос имеет `X-Request-ID`,
  его же содержит запись об ошибке.
- Ротация аудита выполняется вручную (срок хранения задаётся политикой):
  удаляйте записи старше срока через `sqlite3` после резервной копии.
- Периодически выполняйте `PRAGMA quick_check;` для SQLite и следите за местом
  на диске (WAL-файлы `-wal`/`-shm` растут при интенсивной записи).
- `metrics_retention_days` и `event_retention_days` в «Настройках» задают сроки
  хранения; фактическую очистку выполняет модуль хранения/сбора.

## 10. Диагностика

| Симптом | Причина и решение |
| --- | --- |
| `/` отдаёт `503` с текстом про `npm run build` | не собрана панель: `cd web/frontend && npm ci && npm run build` |
| `401` на все запросы | истекла сессия или не задан ключ; войдите заново |
| `403 csrf_failed` | нет заголовка `X-CSRF-Token`; обновите страницу и повторите |
| `429` при входе | сработала блокировка; подождите `Retry-After` секунд |
| `COOKIE_SECURE=false` в проверках | включите HTTPS и `COOKIE_SECURE=true` |
| Источник метрик `SQLite` вместо `ClickHouse` | ClickHouse недоступен, смотрите `system_status` и `journalctl` |
| «Нет данных» на графиках | не запущен collector или неверный `STORAGE_BACKEND` |
| Правило в статусе `pending` | не реализован/не подключён Rule Manager (часть Кирилла) |

## 11. Чек-лист приёмки (ТЗ §11–12)

- [ ] `NETSHIELD_SECRET_KEY` задан, уникален, не хранится в git.
- [ ] `COOKIE_SECURE=true`, `TRUST_PROXY_HEADERS=true`, HTTPS работает,
      HTTP перенаправляется на HTTPS.
- [ ] `CSRF_ENABLED=true`; изменяющие запросы без токена получают `403`.
- [ ] Ограничение частоты входа настроено и в приложении, и в nginx.
- [ ] `.env`, БД и резервные копии доступны только сервису и администраторам.
- [ ] Порт 8000 не доступен извне; проверено с другой машины.
- [ ] ClickHouse-пользователь панели имеет только необходимые права
      (`SELECT`, `CREATE TABLE`, `ALTER TABLE`), без `INSERT`/`DROP`.
- [ ] В логах и аудите нет паролей, токенов, cookie и хэшей.
- [ ] `/api/health` опрашивается мониторингом; алерт на `503`.
- [ ] Резервная копия SQLite создаётся по расписанию и проверена восстановлением.
- [ ] Сроки хранения метрик и событий соответствуют политике.
- [ ] Проверены пустые состояния: нет метрик, нет событий, нет правил.
- [ ] `docs/api.md` и Swagger `/api/docs` актуальны; `docs/integration.md`
      согласован с модулями firewall и collector.
- [ ] `python -m pytest tests/test_auth.py tests/test_api.py -q` проходит.

## 12. Ограничения и направления развития

Ограничения текущей версии (осознанно зафиксированы в рамках ТЗ):

- **Одна роль** — администратор. Отдельного наблюдателя с доступом только на
  чтение нет; любая активная сессия может менять конфигурацию.
- **Один процесс uvicorn.** Счётчик неудачных входов хранится в памяти
  процесса, поэтому при нескольких worker'ах лимит будет считаться отдельно.
  Для горизонтального масштабирования нужен общий store (Redis) или ограничение
  на уровне nginx.
- **Аудит не ротируется автоматически.** Срок хранения и очистка — задача
  администратора/регламента; метрики и события чистит модуль сбора.
- **Панель — SPA без SSR.** Требуется сборка `web/static/dist`; при её
  отсутствии корневой маршрут отвечает `503`, API продолжает работать.
- **Применение правил зависит от части Кирилла.** До появления
  `app/firewall/integration.py` правила сохраняются со статусом `pending`.
- **Статистика агрегируется на стороне API** из серий метрик и событий; готовых
  материализованных витрин за длительные периоды нет.
- **Нет встроенных оповещений** (e-mail/Telegram/webhook) и экспорта отчётов;
  мониторинг строится на `/api/health` и внешней системе.

Возможные направления развития: RBAC и MFA, экспорт аудита и отчётов, алерты по
событиям и деградации компонентов, материализованные агрегаты в ClickHouse,
публикация метрик Prometheus, тёмная/светлая темы и локализация интерфейса,
автоматическая ротация журналов, интеграция с внешним SIEM.
