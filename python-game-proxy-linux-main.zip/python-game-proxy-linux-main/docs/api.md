# REST API NetShield

Базовый префикс: `/api`. Формат — JSON. Схема: `/api/docs` (Swagger UI) и
`/api/openapi.json`. Все эндпоинты, кроме `/api/health`, `/api/auth/csrf` и
`/api/auth/login`, требуют активной сессии.

## Аутентификация и CSRF

Сессия хранится в подписанной cookie `netshield_session`. Любой изменяющий запрос
(`POST`, `PUT`, `PATCH`, `DELETE`) обязан содержать заголовок `X-CSRF-Token`,
полученный от `GET /api/auth/csrf` или `GET /api/auth/me`. Иначе — `403`:

```json
{"detail": "CSRF-токен отсутствует или недействителен", "code": "csrf_failed"}
```

### `GET /api/auth/csrf`

Возвращает (и при необходимости создаёт) CSRF-токен для текущей сессии.

```json
{"csrf_token": "P3q...Yw"}
```

### `POST /api/auth/login`

```json
{"login": "admin", "password": "secret"}
```

Успех `200`:

```json
{
  "user": {"id": 1, "login": "admin", "is_admin": true},
  "csrf_token": "новый токен"
}
```

Ошибки: `401` — неверные данные (общее сообщение, без указания, что именно
неверно), `422` — ошибка валидации, `429` — превышен лимит попыток (заголовок
`Retry-After`).

### `GET /api/auth/me`

Текущий пользователь и актуальный CSRF-токен. `401`, если сессии нет.

### `POST /api/auth/logout`

Требует CSRF. Возвращает `204` и удаляет cookie сессии. Действие попадает в аудит.

## Серверы

| Метод | Путь | Описание |
| --- | --- | --- |
| `GET` | `/api/servers` | Список серверов с портами |
| `POST` | `/api/servers` | Создать сервер (`201`) |
| `GET` | `/api/servers/{id}` | Один сервер |
| `PATCH` | `/api/servers/{id}` | Частичное обновление |
| `DELETE` | `/api/servers/{id}` | Удалить (`204`) |
| `GET` | `/api/servers/{id}/ports` | Порты сервера |
| `PUT` | `/api/servers/{id}/ports` | Заменить список портов |

Пример создания:

```json
{
  "name": "Game #1",
  "ip": "203.0.113.10",
  "interface": "eth0",
  "profile": "game",
  "service_type": "game",
  "internal_ip": "10.0.0.10",
  "internal_port": 27015,
  "description": "основной игровой сервер",
  "is_active": true,
  "max_pps": 5000,
  "max_bps": 100000000,
  "max_new_tcp_per_s": 200,
  "max_udp_pps": 3000,
  "max_new_sources": 100,
  "max_connections": 2000,
  "ports": [
    {"port": 27015, "protocol": "udp", "service_type": "game"},
    {"port": 8080, "protocol": "tcp", "service_type": "web"}
  ]
}
```

Валидация (`422`):

- `ip` и `internal_ip` — только корректный IPv4/IPv6;
- `port` — 1…65535, `internal_port` — 0…65535;
- `protocol` — `tcp` / `udp` / `both`, `profile` и `service_type` — `web` / `game` / `custom`;
- `interface` — `[A-Za-z0-9_.:@-]`, до 32 символов;
- запрещены управляющие символы и лишние поля (например `command`, `shell`).

## Метрики

| Метод | Путь | Параметры |
| --- | --- | --- |
| `GET` | `/api/metrics/traffic` | `range=5m\|1h\|24h\|7d`, `server_id` |
| `GET` | `/api/metrics/connections` | `range`, `server_id` |
| `GET` | `/api/metrics/overview` | — |

Ответ серии:

```json
{
  "range": "1h",
  "server_id": 1,
  "bucket_seconds": 30,
  "has_data": true,
  "stale": false,
  "message": null,
  "last_sample": "2026-10-25T09:55:12",
  "source": "clickhouse",
  "points": [
    {"ts": "2026-10-25T09:55:00+00:00", "in_pps": 124.5, "out_pps": 98.1,
     "in_bps": 1500000.0, "out_bps": 900000.0, "in_bytes": 120000, "out_bytes": 80000,
     "samples": 30}
  ]
}
```

- `has_data=false` — метрик за период нет (панель показывает «Нет данных»);
- `stale=true` — последняя точка слишком старая для выбранного диапазона;
- `source` — фактическое хранилище (`clickhouse` или `sqlite`).

`/api/metrics/overview` возвращает `gateway` (число серверов, режим, источник
метрик), `totals` (суммарный pps/бит/с и события за 24 часа) и `items` — по
серверу: последние значения и признак свежести данных.

## Статистика

### `GET /api/stats`

Сводная статистика за период — источник для страницы «Статистика». Параметры:
`range=5m|1h|24h|7d` (по умолчанию `24h`) и необязательный `server_id`.

```json
{
  "range": "24h",
  "server_id": null,
  "window_seconds": 86400,
  "source": "clickhouse",
  "has_data": true,
  "message": null,
  "traffic": {
    "has_data": true,
    "points": 288,
    "bucket_seconds": 300,
    "peak_in_pps": 4521.3,
    "peak_out_pps": 1802.7,
    "avg_in_pps": 1200.4,
    "avg_out_pps": 480.9,
    "total_in_bytes": 182340000,
    "total_out_bytes": 90120000,
    "samples": 86400,
    "series": [
      {"ts": "2026-10-25T09:55:00+00:00", "in_pps": 124.5, "out_pps": 98.1,
       "in_bps": 1500000.0, "out_bps": 900000.0}
    ]
  },
  "events": {
    "total": 12,
    "by_severity": [
      {"severity": "high", "count": 5, "avg_score": 0.82,
       "last_event": "2026-10-25T09:40:00"}
    ],
    "by_type": [
      {"event_type": "udp_flood", "count": 7, "avg_score": 0.74, "last_event": "..."}
    ],
    "by_protocol": [
      {"protocol": "udp", "count": 9, "avg_score": 0.77, "last_event": "..."}
    ],
    "by_status": [
      {"action_status": "proposed", "count": 10, "avg_score": 0.75, "last_event": "..."}
    ]
  },
  "rules": {
    "active": 3,
    "temporary": 2,
    "permanent": 1,
    "expired": 0,
    "created_in_period": 1,
    "actions_in_period": 4,
    "by_action": [{"action": "rate_limit", "count": 2}]
  }
}
```

- `traffic.series[].ts` — ISO-время в UTC (`+00:00`), шаг — `bucket_seconds`;
- `events.total` — сумма событий за период; разбивки содержат `count`,
  `avg_score` и `last_event`;
- `rules.active` — правила с `is_active=1` (как в `/api/rules`); `temporary`,
  `permanent` и `expired` делят их по сроку действия;
- `rules.created_in_period` — правила, созданные за период (включая снятые);
- `rules.actions_in_period` — число применений правил по журналу аудита
  (`rule.apply`);
- `has_data=false` и `message` — за период нет ни метрик, ни событий, ни правил.

Периоды и шаг агрегации: `5m` → 5 с, `1h` → 30 с, `24h` → 300 с, `7d` → 1800 с.

## События

### `GET /api/events`

Параметры: `server_id`, `severity` (`info|low|medium|high|critical`), `event_type`,
`protocol` (`tcp|udp`), `action_status`, `hours` (1…720), `page`, `page_size`
(1…200).

```json
{
  "items": [
    {"id": 12, "server_id": 1, "server_name": "Game #1",
     "timestamp": "2026-10-25T09:40:00", "event_type": "udp_flood",
     "protocol": "udp", "score": 0.91, "severity": "high",
     "details": "{\"pps\": 120000}", "action_status": "proposed"}
  ],
  "total": 1, "page": 1, "page_size": 50,
  "has_data": true, "message": null, "range_hours": 24
}
```

### `GET /api/events/stats`

Параметры `server_id`, `hours`, `group_by`
(`severity|event_type|protocol|action_status`, по умолчанию `severity`).
Возвращает количество событий, среднюю оценку и время последнего события в
группе:

```json
{
  "group_by": "severity",
  "items": [
    {"severity": "high", "count": 2, "avg_score": 0.8,
     "last_event": "2026-10-25T09:40:00"}
  ],
  "total": 2
}
```

Для `group_by=protocol` поле группы называется `protocol`, для
`action_status` — `action_status`, для `event_type` — `event_type`.

## Правила

| Метод | Путь | Описание |
| --- | --- | --- |
| `GET` | `/api/rules` | Активные правила (`server_id`, `status_filter=all\|temporary\|permanent\|expired`) |
| `POST` | `/api/rules` | Создать правило (`201`) |
| `DELETE` | `/api/rules/{id}` | Снять правило |

```json
{
  "server_id": 1,
  "action": "rate_limit",
  "ip": "198.51.100.7",
  "port": 27015,
  "protocol": "udp",
  "ttl_seconds": 300,
  "reason": "UDP-флуд"
}
```

Допустимые действия: `rate_limit`, `block_source`, `block_port`, `drop`, `alert`.
`ttl_seconds=0` — бессрочное правило.

Ответ:

```json
{"status": "pending", "message": "Rule Manager недоступен: ...", "rule_id": 5}
```

- `applied` — правило применено менеджером firewall;
- `pending` — сохранено в БД, ждёт интеграции с nftables (нормальный режим до
  готовности части Кирилла);
- `rejected` → HTTP `400` (например, порт не принадлежит серверу);
- `error` → HTTP `502` (ошибка менеджера firewall).

## Настройки

`GET /api/settings`, `PUT /api/settings`.

```json
{
  "detection_mode": "observation",
  "auto_actions_enabled": false,
  "collection_interval_sec": 1,
  "confirmation_intervals": 3,
  "cooldown_seconds": 60,
  "max_concurrent_blocks": 20,
  "metrics_retention_days": 7,
  "event_retention_days": 90
}
```

`detection_mode=auto` принудительно включает `auto_actions_enabled`. Изменение
настроек фиксируется в аудите.

## Аудит

### `GET /api/audit`

Параметры: `action` (подстрока), `result` (`ok|fail`), `hours` (1…2160), `page`,
`page_size`. Возвращает `{items, total, page, page_size, has_data, message}`.
В `details` чувствительные поля замаскированы (`***`).

## Безопасность и здоровье

### `GET /api/security/status`

```json
{
  "checks": [
    {"name": "Ключ сессий", "status": "ok", "message": "задан в окружении"},
    {"name": "Cookie Secure/HttpOnly", "status": "warn", "message": "COOKIE_SECURE=false ..."}
  ],
  "components": [
    {"component": "clickhouse", "status": "ok", "message": "подключено",
     "updated_at": "2026-10-25T09:00:00"}
  ]
}
```

### `GET /api/health` (без авторизации)

`200` — всё в порядке; `503` — деградация.

```json
{"status": "ok", "config_db": true, "metrics_db": true, "metrics_source": "sqlite"}
```

## Коды ошибок

| Код | Значение |
| --- | --- |
| `400` | Некорректный запрос (например, порт не принадлежит серверу) |
| `401` | Нет сессии или неверные учётные данные |
| `403` | Нет прав или не пройдена CSRF-проверка |
| `404` | Объект не найден |
| `422` | Ошибка валидации входных данных |
| `429` | Превышен лимит попыток входа |
| `500` | Внутренняя ошибка (с `request_id` в ответе и логах) |
| `502` | Ошибка менеджера firewall |
| `503` | Фронтенд не собран / сервис деградировал |
