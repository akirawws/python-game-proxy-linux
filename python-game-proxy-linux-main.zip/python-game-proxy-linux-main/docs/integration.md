# Контракты интеграции

Документ фиксирует интерфейсы между частями проекта, чтобы модули собирались без
переделок. Владелец контрактов — все три участника; изменения согласовываются.

## 1. Менеджер firewall (Кирилл)

Панель **не выполняет shell-команды**. Единственная точка интеграции —
`app/firewall/integration.py`:

```python
# app/firewall/integration.py
def create_rule_manager(repository) -> "RuleManager":
    ...
```

Вызывается лениво из `app/api/rule_service.py::RuleService._manager()`. Если модуль
или функция отсутствуют (либо создание упало), API сохраняет правило в БД и
возвращает `status: "pending"` — панель остаётся работоспособной.

### Ожидаемый API RuleManager

```python
manager.apply_decision(decision) -> object
# у результата читаются:
#   .status  -> "applied" | "proposed" | "rejected" | ...
#   .reason  -> человекочитаемая причина (может быть пустой)
```

### RuleDecision

```python
RuleDecision(
    action=ActionType.RATE_LIMIT,   # RATE_LIMIT | BLOCK_SOURCE | PORT_RULE | DROP | ALERT
    server_id=1,
    ip="198.51.100.7",
    port=27015,
    protocol="udp",
    expires_at=datetime | None,
    reason="UDP-флуд",
)
```

Соответствие действий API → `ActionType`:

| API (`RuleIn.action`) | `ActionType` |
| --- | --- |
| `rate_limit` | `RATE_LIMIT` |
| `block_source` | `BLOCK_SOURCE` |
| `block_port` | `PORT_RULE` |
| `drop` | `DROP` |
| `alert` | `ALERT` |

Если в `ActionType` нет нужного члена, правило не применяется, API возвращает
`status: "error"` (`502`).

### Методы Repository, на которые можно опираться

```python
get_active_rules(server_id: int | None = None) -> list[dict]
list_rules(server_id=None, status="all") -> list[dict]
get_rule(rule_id: int) -> dict | None
create_rule(data: dict) -> int
deactivate_rule(rule_id: int) -> bool
append_audit(action: str, details: str = "", user_id=None, result="ok") -> int
fetch_all(table: str, where: str = "", params: tuple = (), order_by: str = "") -> list[dict]
fetch_one(table: str, where: str, params: tuple = ()) -> dict | None
insert(table: str, model) -> int
insert_row(table: str, data: dict) -> int
update(table: str, record_id: int, **fields) -> None
```

Строки `firewall_rules` содержат поля: `id`, `server_id`, `ip`, `port`, `protocol`,
`action`, `expires_at`, `is_active`, `rule_type`, `reason`, `created_at`.

Менеджер может писать собственные записи аудита (`apply`, `base_rules`, `config`) —
таблица `audit_logs` (`user_id`, `timestamp`, `action`, `details`, `result`).

## 2. Хранилище метрик (Денис)

### Модели (`app/storage/models.py`)

`ProtectedServer`: `id, name, ip, interface, max_pps, max_bps, max_new_tcp_per_s,
max_udp_pps, max_new_sources, max_connections, is_active, description,
service_type, internal_ip, internal_port, profile`

`ProtectedPort`: `id, server_id, port, protocol, service_type`

`TrafficMetric`: `id, server_id, timestamp, in_bytes, out_bytes, in_pps, out_pps,
in_bps, out_bps`

`ConnectionMetric`: `id, server_id, timestamp, tcp_new, udp_pps, conntrack_count,
new_sources`

`AnomalyEvent`: `id, server_id, timestamp, event_type, score, severity, details,
action_status, protocol`

`FirewallRule`: `id, server_id, ip, port, protocol, action, expires_at, is_active,
rule_type, reason, created_at`

`AuditLog`: `id, user_id, timestamp, action, details, result`

Значения `severity`: `info`, `low`, `medium`, `high`, `critical`.
Значения `action_status`: `proposed`, `pending`, `applied`, `rejected`.

### Методы хранилища метрик

`Repository` (SQLite) и `ClickHouseRepository` должны поддерживать одинаковый
набор вызовов, используемых API:

```python
query_traffic_series(server_id, date_from, date_to, bucket_seconds) -> list[dict]
query_connection_series(server_id, date_from, date_to, bucket_seconds) -> list[dict]
list_events(server_id=None, severity=None, event_type=None, protocol=None,
            action_status=None, date_from=None, date_to=None,
            page=1, page_size=50) -> tuple[list[dict], int]
event_stats(server_id=None, date_from=None, date_to=None,
            group_by="severity") -> list[dict]
latest_metric(server_id) -> dict | None      # {"timestamp": ...}
latest_event(server_id) -> dict | None       # {"timestamp": ...}
health_check() -> bool
```

Серии возвращаются словарями с ключом `bucket` — номер секунды (Unix time,
округлённый до `bucket_seconds`), плюс агрегаты. API сам превращает `bucket` в
ISO-время `ts` (UTC).

Времена в SQLite хранятся как ISO-строки **без таймзоны в UTC**; ClickHouse
использует `DateTime64`. API сравнивает их в UTC и отдаёт в ISO с `+00:00`.

Если `STORAGE_BACKEND=clickhouse`, но соединение не удалось, панель читает метрики
из SQLite и фиксирует ошибку в `system_status` (компонент `clickhouse`).

`event_stats(group_by=...)` поддерживает группировку по `severity`, `event_type`,
`protocol` и `action_status`. Строки содержат поле группы, `count`, `avg_score`
и `last_event`. Этот вызов используют `/api/events/stats` и `/api/stats`
(раздел «Статистика»).

## 3. Что панель гарантирует остальным

- Конфигурация (серверы, порты, правила, настройки, пользователи) всегда в SQLite,
  схема обновляется автоматически при старте.
- Изменения серверов/правил/настроек и все входы фиксируются в `audit_logs`.
- API никогда не вызывает `subprocess`/`os.system`.
- Правило, созданное через API, сначала попадает в БД, затем передаётся менеджеру
  firewall; при ошибке менеджера правило остаётся в БД со статусом ошибки в ответе.
- Все порты правила проверяются на принадлежность выбранному серверу.
